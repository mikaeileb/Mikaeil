# TradePilot Android project

این بسته شامل پروژه برنامه در پوشه `TradePilot/` و workflow ساخت APK در مسیر `.github/workflows/tradepilot-android.yml` است.

## ساخت APK با GitHub

1. این ZIP را در ریشه یک مخزن GitHub استخراج کن؛ در نتیجه دو مسیر `TradePilot/` و `.github/workflows/tradepilot-android.yml` در ریشه مخزن قرار می‌گیرند.
2. تغییرات را روی شاخه `main` commit و push کن.
3. در تب **Actions** اجرای **Build TradePilot Android APK** را باز کن.
4. پس از موفقیت ساخت، از بخش **Artifacts** فایل `TradePilot-Android-APK` را دریافت و `app-debug.apk` را از ZIP استخراج کن.

همچنین می‌توانی workflow را از تب Actions با گزینه **Run workflow** دستی اجرا کنی.

## ساخت محلی

نیازمندی‌ها: Node.js 22، JDK 21، Android SDK و ابزارهای Android SDK.

```bash
cd TradePilot
npm install
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

خروجی: `TradePilot/android/app/build/outputs/apk/debug/app-debug.apk`

این workflow نسخه debug برای نصب و تست تولید می‌کند، نه نسخه release امضاشده برای انتشار فروشگاهی.
