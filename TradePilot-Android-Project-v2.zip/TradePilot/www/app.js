/* TradePilot - client-side analysis engine. No order execution or exchange secrets. */
(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const STORAGE = { settings: 'tp_settings_v1', journal: 'tp_journal_v1' };
  const DEFAULTS = { market: 'spot', symbol: 'BTCUSDT', timeframe: '1h', balance: 1000, risk: 1, leverage: 1, rr: 2, twelveKey: '' };
  const CRYPTO = [
    ['BTCUSDT','BTC/USDT'],['ETHUSDT','ETH/USDT'],['BNBUSDT','BNB/USDT'],['SOLUSDT','SOL/USDT'],
    ['XRPUSDT','XRP/USDT'],['ADAUSDT','ADA/USDT'],['LINKUSDT','LINK/USDT'],['AVAXUSDT','AVAX/USDT'],['DOGEUSDT','DOGE/USDT']
  ];
  const FOREX = [
    ['EUR/USD','EUR/USD'],['GBP/USD','GBP/USD'],['AUD/USD','AUD/USD'],['NZD/USD','NZD/USD'],['USD/JPY','USD/JPY'],['XAU/USD','XAU/USD']
  ];
  const TF_MS = { '15m': 900000, '1h': 3600000, '4h': 14400000, '1d': 86400000 };
  const TD_TF = { '15m':'15min', '1h':'1h', '4h':'4h', '1d':'1day' };
  let settings = load(STORAGE.settings, DEFAULTS);
  settings = { ...DEFAULTS, ...settings };
  let journal = load(STORAGE.journal, []);
  let activeCandles = [];
  let currentAnalysis = null;
  let currentPrice = null;
  let currentChange = null;
  let lastUpdate = null;
  let ws = null;
  let priceTimer = null;
  let autoScanTimer = null;
  let toastTimer = null;
  let scannerBusy = false;
  let lastForexCandleFetch = 0;

  function load(key, fallback) {
    try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : fallback; }
    catch (_) { return fallback; }
  }
  function save(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); } catch (_) {} }
  function esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function num(v, digits=2) {
    const n = Number(v);
    if (!Number.isFinite(n)) return '—';
    const abs = Math.abs(n);
    const d = abs >= 1000 ? Math.min(digits,2) : abs >= 1 ? digits : abs >= .01 ? 4 : 7;
    return n.toLocaleString('en-US', { maximumFractionDigits:d, minimumFractionDigits:0 });
  }
  function faDate(ts) {
    if (!ts) return '—';
    try { return new Date(ts).toLocaleString('fa-IR', {year:'2-digit',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}); }
    catch (_) { return new Date(ts).toLocaleString(); }
  }
  function showToast(message) {
    const el = $('toast'); el.textContent = message; el.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 2600);
  }
  function setConnection(status, label) {
    const el = $('connectionPill');
    el.className = 'status-pill ' + (status || 'muted');
    el.innerHTML = '<i></i> ' + esc(label || 'در انتظار داده');
  }
  function activeList() { return settings.market === 'forex' ? FOREX : CRYPTO; }
  function displaySymbol(value) {
    const item = activeList().find(x => x[0] === value);
    if (item) return item[1];
    return settings.market === 'forex' ? value : value.replace(/(USDT|BUSD|USDC)$/,'/$1');
  }
  function updateSymbolOptions() {
    const select = $('symbolSelect');
    const list = activeList();
    if (!list.some(x => x[0] === settings.symbol)) settings.symbol = list[0][0];
    select.innerHTML = list.map(x => `<option value="${esc(x[0])}">${esc(x[1])}</option>`).join('');
    select.value = settings.symbol;
    $('assetSymbol').textContent = displaySymbol(settings.symbol);
    $('sourceLabel').textContent = settings.market === 'spot' ? 'Binance Spot' : settings.market === 'futures' ? 'Binance USDⓈ-M Futures' : 'Twelve Data';
    $('marketNote').textContent = settings.market === 'forex' ? 'برای فارکس/طلا، API Key لازم است' : settings.market === 'futures' ? 'داده عمومی قراردادهای آتی · بدون دسترسی معاملاتی' : 'قیمت بازار نقدی · بدون API Key';
  }
  function persistSettings() { save(STORAGE.settings, settings); }

  async function requestJson(url, timeoutMs=14000) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(url, { signal: controller.signal, cache: 'no-store' });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const json = await response.json();
      if (json && (json.code || json.status === 'error')) throw new Error(json.msg || json.message || 'خطای منبع داده');
      return json;
    } finally { clearTimeout(timer); }
  }
  function cryptoBase() {
    return settings.market === 'futures' ? ['https://fapi.binance.com/fapi/v1'] : [
      'https://data-api.binance.vision/api/v3', 'https://api.binance.com/api/v3', 'https://api1.binance.com/api/v3'
    ];
  }
  async function cryptoGet(path, params={}) {
    const query = new URLSearchParams(params).toString();
    let lastError;
    for (const base of cryptoBase()) {
      try { return await requestJson(`${base}/${path}${query ? '?' + query : ''}`); }
      catch (error) { lastError = error; }
    }
    throw lastError || new Error('دسترسی به منبع قیمت ممکن نشد');
  }
  function parseBinanceCandle(k) {
    return { t:Number(k[0]), o:Number(k[1]), h:Number(k[2]), l:Number(k[3]), c:Number(k[4]), v:Number(k[5]), closeTime:Number(k[6]) };
  }
  async function getCandles(symbol=settings.symbol, timeframe=settings.timeframe, limit=280) {
    if (settings.market === 'forex') {
      if (!settings.twelveKey) throw new Error('برای فارکس و طلا ابتدا API Key سرویس Twelve Data را در تنظیمات وارد کن.');
      const url = new URL('https://api.twelvedata.com/time_series');
      url.searchParams.set('symbol', symbol); url.searchParams.set('interval', TD_TF[timeframe] || '1h');
      url.searchParams.set('outputsize', String(Math.min(limit,500))); url.searchParams.set('order','ASC');
      url.searchParams.set('timezone','UTC'); url.searchParams.set('apikey',settings.twelveKey);
      const data = await requestJson(url.toString());
      if (!Array.isArray(data.values)) throw new Error(data.message || 'داده کندل از Twelve Data دریافت نشد.');
      const step = TF_MS[timeframe] || 3600000;
      return data.values.map(x => {
        const t = Date.parse(x.datetime.replace(' ','T') + (/[zZ]|[+-]\d\d:?\d\d$/.test(x.datetime) ? '' : 'Z'));
        return { t, o:+x.open, h:+x.high, l:+x.low, c:+x.close, v:+(x.volume || 0), closeTime:t+step-1 };
      }).filter(c => [c.t,c.o,c.h,c.l,c.c].every(Number.isFinite)).sort((a,b)=>a.t-b.t);
    }
    const path = settings.market === 'futures' ? 'klines' : 'klines';
    const raw = await cryptoGet(path, { symbol, interval:timeframe, limit:String(Math.min(limit,500)) });
    return raw.map(parseBinanceCandle).filter(c => [c.t,c.o,c.h,c.l,c.c].every(Number.isFinite));
  }
  async function getPrice(symbol=settings.symbol) {
    if (settings.market === 'forex') {
      if (!settings.twelveKey) throw new Error('API Key سرویس Twelve Data در تنظیمات وارد نشده است.');
      const url = new URL('https://api.twelvedata.com/price'); url.searchParams.set('symbol',symbol); url.searchParams.set('apikey',settings.twelveKey);
      const data = await requestJson(url.toString()); return Number(data.price);
    }
    const data = await cryptoGet('ticker/price', {symbol});
    return Number(data.price);
  }
  async function getChange(symbol=settings.symbol) {
    if (settings.market === 'forex') return null;
    try {
      const data = await cryptoGet('ticker/24hr', {symbol});
      return Number(data.priceChangePercent);
    } catch (_) { return null; }
  }
  function startLiveFeed() {
    stopLiveFeed();
    if (settings.market !== 'forex' && 'WebSocket' in window) {
      const streamSymbol = settings.symbol.toLowerCase();
      const base = settings.market === 'futures' ? 'wss://fstream.binance.com/ws/' : 'wss://data-stream.binance.vision/ws/';
      try {
        ws = new WebSocket(`${base}${streamSymbol}@kline_${settings.timeframe}`);
        ws.onopen = () => setConnection('ok','داده زنده متصل');
        ws.onmessage = ev => {
          try {
            const msg = JSON.parse(ev.data); const k = msg.k;
            if (!k) return;
            const c = {t:+k.t,o:+k.o,h:+k.h,l:+k.l,c:+k.c,v:+k.v,closeTime:+k.T};
            const idx = activeCandles.findIndex(x => x.t === c.t);
            if (idx >= 0) activeCandles[idx] = c; else activeCandles.push(c);
            activeCandles.sort((a,b)=>a.t-b.t);
            currentPrice = c.c; $('mainPrice').textContent = num(currentPrice, 4);
            lastUpdate = Date.now(); $('lastUpdated').textContent = 'به‌روزرسانی: ' + faDate(lastUpdate);
            drawChart();
            if (k.x) { const closed = getClosedCandles(activeCandles); currentAnalysis = analyzeCandles(closed); renderAnalysis(); }
          } catch (_) {}
        };
        ws.onerror = () => setConnection('bad','اختلال در جریان زنده');
        ws.onclose = () => { if (settings.market !== 'forex') setConnection('muted','اتصال زنده قطع شد · تلاش مجدد با قیمت دوره‌ای'); };
      } catch (_) { setConnection('muted','قیمت‌گیری دوره‌ای فعال'); }
    }
    priceTimer = setInterval(refreshPriceOnly, settings.market === 'forex' ? 120000 : 15000);
  }
  function stopLiveFeed() {
    if (ws) { try { ws.close(); } catch (_) {} ws = null; }
    if (priceTimer) clearInterval(priceTimer); priceTimer = null;
  }
  async function refreshPriceOnly() {
    try {
      const [price, change] = await Promise.all([getPrice(), getChange()]);
      if (!Number.isFinite(price)) throw new Error('قیمت معتبر نیست');
      currentPrice = price; currentChange = change; lastUpdate = Date.now();
      if (settings.market === 'forex' && Date.now() - lastForexCandleFetch > 600000) {
        try { activeCandles = await getCandles(settings.symbol, settings.timeframe, 280); lastForexCandleFetch = Date.now(); currentAnalysis = analyzeCandles(getClosedCandles(activeCandles)); renderAnalysis(); drawChart(); } catch (candleError) { console.warn(candleError); }
      }
      $('mainPrice').textContent = num(price, 5);
      if (change !== null && Number.isFinite(change)) {
        const el = $('priceChange'); el.textContent = `${change >= 0 ? '▲' : '▼'} ${num(Math.abs(change),2)}% در ۲۴ ساعت`;
        el.className = 'price-change ' + (change >= 0 ? 'up':'down');
      } else $('priceChange').textContent = 'نرخ لحظه‌ای · تغییر روزانه در دسترس نیست';
      $('lastUpdated').textContent = 'به‌روزرسانی: ' + faDate(lastUpdate);
      if (!ws || ws.readyState !== WebSocket.OPEN) setConnection('ok','قیمت به‌روز');
    } catch (error) {
      setConnection('bad','عدم دسترسی به قیمت');
      if (!currentPrice) $('mainPrice').textContent = 'قیمت در دسترس نیست';
      console.warn(error);
    }
  }
  function getClosedCandles(candles) {
    const duration = TF_MS[settings.timeframe] || 3600000;
    const now = Date.now();
    return candles.filter(c => (c.closeTime || c.t + duration - 1) < now - 500);
  }

  function ema(values, period) {
    const out = Array(values.length).fill(null); if (values.length < period) return out;
    const k = 2/(period+1); let sum=0;
    for (let i=0;i<period;i++) sum += values[i];
    let prev=sum/period; out[period-1]=prev;
    for (let i=period;i<values.length;i++) { prev=values[i]*k+prev*(1-k); out[i]=prev; }
    return out;
  }
  function sma(values, period, end=values.length-1) {
    if (end-period+1<0) return null;
    let s=0; for (let i=end-period+1;i<=end;i++) s+=values[i]; return s/period;
  }
  function rsi(values, period=14) {
    if (values.length <= period) return null;
    let gain=0,loss=0;
    for(let i=1;i<=period;i++){const d=values[i]-values[i-1];if(d>0)gain+=d;else loss-=d;}
    let ag=gain/period, al=loss/period;
    for(let i=period+1;i<values.length;i++){const d=values[i]-values[i-1];ag=(ag*(period-1)+Math.max(d,0))/period;al=(al*(period-1)+Math.max(-d,0))/period;}
    if(al===0) return 100; return 100-(100/(1+ag/al));
  }
  function atr(candles, period=14) {
    if(candles.length < period+1) return null;
    const trs=[];
    for(let i=1;i<candles.length;i++) trs.push(Math.max(candles[i].h-candles[i].l,Math.abs(candles[i].h-candles[i-1].c),Math.abs(candles[i].l-candles[i-1].c)));
    let value=trs.slice(0,period).reduce((a,b)=>a+b,0)/period;
    for(let i=period;i<trs.length;i++) value=(value*(period-1)+trs[i])/period;
    return value;
  }
  function macd(values) {
    if(values.length<35) return null;
    const e12=ema(values,12), e26=ema(values,26);
    const line=values.map((_,i)=>e12[i]!==null&&e26[i]!==null?e12[i]-e26[i]:null);
    const start=line.findIndex(x=>x!==null); const compressed=line.slice(start);
    const sig=ema(compressed,9); const signal=Array(values.length).fill(null);
    for(let i=0;i<sig.length;i++) signal[start+i]=sig[i];
    const hist=line.map((x,i)=>x!==null&&signal[i]!==null?x-signal[i]:null);
    return {line,signal,hist};
  }
  function bollinger(values, period=20, mult=2) {
    if(values.length<period) return null;
    const mid=sma(values,period); const slice=values.slice(-period); const variance=slice.reduce((s,x)=>s+(x-mid)**2,0)/period; const sd=Math.sqrt(variance);
    return {mid,upper:mid+mult*sd,lower:mid-mult*sd};
  }
  function candleShape(c) {
    const body=Math.abs(c.c-c.o), range=Math.max(c.h-c.l,1e-12), upper=c.h-Math.max(c.o,c.c), lower=Math.min(c.o,c.c)-c.l;
    return {body,range,upper,lower,bull:c.c>c.o,bear:c.c<c.o};
  }
  function analyzeCandles(candles) {
    if(!candles || candles.length<65) return {direction:'NONE',score:0,confidence:0,reason:'برای تحلیل معتبر حداقل ۶۵ کندل لازم است.',setups:[],metrics:{}};
    const closes=candles.map(c=>c.c), volumes=candles.map(c=>c.v||0), n=candles.length, last=candles[n-1], prev=candles[n-2];
    const e20=ema(closes,20), e50=ema(closes,50), m=macd(closes), rr=rsi(closes), av=atr(candles), bb=bollinger(closes);
    const i=n-1, prevI=n-2, e20v=e20[i],e50v=e50[i], r=rr;
    if(![e20v,e50v,r,av].every(Number.isFinite)) return {direction:'NONE',score:0,confidence:0,reason:'داده کافی برای محاسبه اندیکاتورها وجود ندارد.',setups:[],metrics:{}};
    const add=[]; let long=0,short=0;
    const push=(direction,weight,name,detail)=>{ if(direction==='LONG')long+=weight;else short+=weight;add.push({direction,weight,name,detail}); };
    // 1) Trend-following EMA alignment and pullback continuation.
    if(e20v>e50v && last.c>e20v && r>49 && r<72) push('LONG',1.5,'روند و پولبک EMA','EMA20 بالاتر از EMA50 است؛ قیمت بالای EMA20 و RSI در محدوده مومنتوم صعودی قرار دارد.');
    if(e20v<e50v && last.c<e20v && r<51 && r>28) push('SHORT',1.5,'روند و پولبک EMA','EMA20 پایین‌تر از EMA50 است؛ قیمت زیر EMA20 و RSI در محدوده مومنتوم نزولی قرار دارد.');
    // 2) MACD momentum confirmation.
    if(m && m.hist[i]!==null && m.hist[prevI]!==null && m.hist[i]>0 && m.hist[i]>=m.hist[prevI] && r>51) push('LONG',1.5,'مومنتوم MACD + RSI','هیستوگرام MACD مثبت و رو به تقویت است و RSI بالای ۵۱ قرار دارد.');
    if(m && m.hist[i]!==null && m.hist[prevI]!==null && m.hist[i]<0 && m.hist[i]<=m.hist[prevI] && r<49) push('SHORT',1.5,'مومنتوم MACD + RSI','هیستوگرام MACD منفی و رو به تضعیف است و RSI زیر ۴۹ قرار دارد.');
    // 3) Range breakout with relative volume (volume is not supplied by all FX feeds).
    const lookback=20, highs=candles.slice(n-lookback-1,n-1).map(c=>c.h), lows=candles.slice(n-lookback-1,n-1).map(c=>c.l);
    const priorHigh=Math.max(...highs), priorLow=Math.min(...lows), avgVol=sma(volumes,20,i-1), volOk=avgVol>0&&last.v>avgVol*1.25;
    if(last.c>priorHigh && (volOk || volumes.every(v=>v===0))) push('LONG',2,'شکست محدوده (Breakout)',volOk?'کلوز بالای سقف ۲۰ کندل با حجم بیش از میانگین ثبت شد.':'کلوز بالای سقف ۲۰ کندل ثبت شد؛ فید حجم این نماد را ارائه نمی‌کند.');
    if(last.c<priorLow && (volOk || volumes.every(v=>v===0))) push('SHORT',2,'شکست محدوده (Breakout)',volOk?'کلوز زیر کف ۲۰ کندل با حجم بیش از میانگین ثبت شد.':'کلوز زیر کف ۲۰ کندل ثبت شد؛ فید حجم این نماد را ارائه نمی‌کند.');
    // 4) Bollinger mean reversion: only when price is stretched and RSI agrees.
    if(bb && last.c<=bb.lower*1.002 && r<38) push('LONG',1.5,'بازگشت به میانگین Bollinger','قیمت به باند پایین بولینگر رسیده و RSI وارد ناحیه ضعف/اشباع فروش شده است.');
    if(bb && last.c>=bb.upper*.998 && r>62) push('SHORT',1.5,'بازگشت به میانگین Bollinger','قیمت به باند بالایی بولینگر رسیده و RSI وارد ناحیه کشیدگی صعودی شده است.');
    // 5) Price action: engulfing or decisive pin bar near recent extreme.
    const a=candleShape(last), b=candleShape(prev);
    const bullEngulf=prev.c<prev.o && last.c>last.o && last.o<=prev.c && last.c>=prev.o;
    const bearEngulf=prev.c>prev.o && last.c<last.o && last.o>=prev.c && last.c<=prev.o;
    const nearLow=last.l<=Math.min(...candles.slice(-11,-1).map(c=>c.l))+av*.25;
    const nearHigh=last.h>=Math.max(...candles.slice(-11,-1).map(c=>c.h))-av*.25;
    if(bullEngulf || (a.lower>a.body*2.2 && a.upper<a.body*1.1 && nearLow && a.bull)) push('LONG',1.5,'پرایس‌اکشن (Engulfing / Pin Bar)',bullEngulf?'الگوی پوشای صعودی روی کندل بسته‌شده دیده شد.':'سایه پایینی بلند نزدیک کف کوتاه‌مدت، واکنش خریداران را نشان می‌دهد.');
    if(bearEngulf || (a.upper>a.body*2.2 && a.lower<a.body*1.1 && nearHigh && a.bear)) push('SHORT',1.5,'پرایس‌اکشن (Engulfing / Pin Bar)',bearEngulf?'الگوی پوشای نزولی روی کندل بسته‌شده دیده شد.':'سایه بالایی بلند نزدیک سقف کوتاه‌مدت، واکنش فروشندگان را نشان می‌دهد.');
    // 6) Market structure (higher highs/lows or lower highs/lows across confirmed swings).
    const recent=candles.slice(-9,-1), earlier=candles.slice(-17,-9);
    if(recent.length===8&&earlier.length===8){
      const rh=Math.max(...recent.map(c=>c.h)), rl=Math.min(...recent.map(c=>c.l));
      const eh=Math.max(...earlier.map(c=>c.h)), el=Math.min(...earlier.map(c=>c.l));
      if(rh>eh && rl>el && last.c>e20v) push('LONG',1,'ساختار بازار (HH / HL)','سقف و کف ساختاری اخیر بالاتر از بازه قبلی قرار گرفته‌اند.');
      if(rh<eh && rl<el && last.c<e20v) push('SHORT',1,'ساختار بازار (LH / LL)','سقف و کف ساختاری اخیر پایین‌تر از بازه قبلی قرار گرفته‌اند.');
    }
    const longSet=add.filter(x=>x.direction==='LONG'), shortSet=add.filter(x=>x.direction==='SHORT');
    const gap=Math.abs(long-short);
    let direction='NONE';
    if(long>=3.5 && long-short>=1.25) direction='LONG';
    else if(short>=3.5 && short-long>=1.25) direction='SHORT';
    const score=direction==='LONG'?long:direction==='SHORT'?short:Math.max(long,short);
    const confidence=Math.min(99,Math.round(score/9*100));
    let entry=last.c, stop=null, target=null, rrTarget=Number(settings.rr)||2;
    if(direction==='LONG'){
      const swingLow=Math.min(...candles.slice(-8).map(c=>c.l));
      stop=Math.min(swingLow,entry-av*1.15); const risk=entry-stop; target=entry+risk*rrTarget;
      if(!(stop>0&&risk>0&&risk/entry<.15)) direction='NONE';
    } else if(direction==='SHORT'){
      const swingHigh=Math.max(...candles.slice(-8).map(c=>c.h));
      stop=Math.max(swingHigh,entry+av*1.15); const risk=stop-entry; target=entry-risk*rrTarget;
      if(!(target>0&&risk>0&&risk/entry<.15)) direction='NONE';
    }
    const chosen=direction==='LONG'?longSet:direction==='SHORT'?shortSet:[];
    const setups=add.map(x=>({...x,active:direction!=='NONE'&&x.direction===direction}));
    const reason=direction==='NONE'?'هم‌گرایی کافی وجود ندارد؛ منتظر بسته‌شدن کندل و تأیید بیشتر بمان.':`${chosen.length} تأیید هم‌جهت از خانواده‌های استراتژی دریافت شد.`;
    return {direction,score,confidence,entry,stop,target,rr:rrTarget,reason,setups,longScore:long,shortScore:short,metrics:{rsi:r,atr:av,ema20:e20v,ema50:e50v,macd:m?.hist[i]??null,bb,close:entry, candleTime:last.t, volumeRatio:avgVol>0?last.v/avgVol:null}};
  }

  function positionSize(entry, stop, config=settings) {
    const balance=Number(config.balance), riskPct=Number(config.risk);
    const leverage=config.market==='spot'?1:Math.max(1,Number(config.leverage)||1);
    const price=Number(entry), distance=Math.abs(price-Number(stop));
    if(!(balance>0&&riskPct>0&&price>0&&distance>0&&Number.isFinite(distance))) return null;
    const riskBudget=balance*riskPct/100;
    const desiredUnits=riskBudget/distance;
    // Keep required margin within the account balance; spot is always cash-funded (1x).
    const maxUnitsByMargin=(balance*leverage)/price;
    const units=Math.min(desiredUnits,maxUnitsByMargin);
    const notional=units*price;
    const margin=notional/leverage;
    const riskCash=units*distance;
    const marginLimited=units+1e-12<desiredUnits;
    let unitLabel='واحد دارایی', lots=null;
    if(config.market==='forex'){
      if(String(config.symbol).startsWith('XAU/')) { unitLabel='اونس طلا'; lots=units/100; }
      else { unitLabel='واحد ارز پایه'; lots=units/100000; }
    } else unitLabel='کوین / قرارداد';
    return {balance,riskPct,riskBudget,riskCash,units,notional,margin,leverage,lots,unitLabel,distance,marginLimited};
  }
  function showSize(container, result) {
    if(!result){container.innerHTML='<div class="muted-note">اطلاعات کافی برای محاسبه حجم وجود ندارد.</div>';return;}
    container.innerHTML=`<div class="size-grid"><div class="size-metric highlight"><small>حجم معامله · ${esc(result.unitLabel)}</small><b>${num(result.units,5)}</b></div><div class="size-metric"><small>ارزش اسمی معامله</small><b>${num(result.notional,2)} USD</b></div><div class="size-metric"><small>مارجین تقریبی با اهرم ${result.leverage}x</small><b>${num(result.margin,2)} USD</b></div><div class="size-metric"><small>زیان برآوردی تا استاپ</small><b>${num(result.riskCash,2)} USD</b></div></div>${result.lots!==null?`<div class="muted-note" style="margin-top:9px">حجم تقریبی: ${num(result.lots,4)} لات استاندارد. مشخصات قرارداد بروکر را کنترل کن.</div>`:''}${result.marginLimited?`<div class="muted-note" style="margin-top:8px;color:var(--amber)">حجم به‌دلیل محدودیت موجودی/مارجین کاهش یافته است؛ ریسک واقعی ${num(result.riskCash,2)} دلار است، کمتر از بودجه ریسک هدف ${num(result.riskBudget,2)} دلار.</div>`:''}<div class="muted-note" style="margin-top:8px">فاصله ورود تا استاپ: ${num(result.distance,6)} · کارمزد، اسلیپیج، نرخ تبدیل ارز و funding لحاظ نشده‌اند.</div>`;
  }
  function renderSignal() {
    const box=$('signalCard'); const a=currentAnalysis;
    if(!a){box.innerHTML='<div class="signal-empty"><div class="pulse-ring">⌁</div><strong>در حال تحلیل بازار</strong><span>استراتژی‌ها در حال بررسی داده‌های واقعی هستند.</span></div>';return;}
    const direction=a.direction;
    if(direction==='NONE'){
      box.innerHTML=`<div class="signal-top"><div class="signal-direction none">◌ بدون سیگنال معتبر</div><span class="signal-score">بالاترین امتیاز ${num(a.score,1)}</span></div><h3 class="signal-title">فعلاً صبر کن</h3><p class="signal-desc">${esc(a.reason)}</p><div class="signal-levels"><div class="level"><small>امتیاز خرید</small><b>${num(a.longScore||0,1)}</b></div><div class="level"><small>امتیاز فروش</small><b>${num(a.shortScore||0,1)}</b></div><div class="level"><small>حداقل لازم</small><b>۳٫۵</b></div></div><div class="signal-actions"><span class="muted-note">سیگنال روی کندل بسته‌شده محاسبه می‌شود.</span><button class="tiny-btn" id="saveWatchBtn">ثبت در واچ‌لیست</button></div>`;
      $('saveWatchBtn')?.addEventListener('click',()=>showToast('نماد در واچ‌لیست اسکنر موجود است.'));
      $('sizeCard').innerHTML='<div class="muted-note">تا زمان شکل‌گیری ستاپ معتبر، حجم پیشنهادی صادر نمی‌شود.</div>';
      return;
    }
    const isLong=direction==='LONG'; const dLabel=isLong?'خرید / LONG':'فروش / SHORT';
    const size=positionSize(a.entry,a.stop,settings);
    const shortNote=!isLong&&settings.market==='spot'?'این سناریو در بازار Spot قابل فروش است فقط در صورتی که دارایی را از قبل داشته باشی؛ برای پوزیشن Short از Futures/CFD استفاده می‌شود.':'';
    box.innerHTML=`<div class="signal-top"><div class="signal-direction ${isLong?'long':'short'}">${isLong?'▲':'▼'} سیگنال ${dLabel}</div><span class="signal-score">قدرت هم‌گرایی ${a.confidence}%</span></div><h3 class="signal-title">${esc(a.reason)}</h3><p class="signal-desc">${esc(displaySymbol(settings.symbol))} · ${esc(settings.timeframe)} · بر اساس آخرین کندل بسته‌شده</p><div class="signal-levels"><div class="level"><small>ورود پیشنهادی</small><b>${num(a.entry,5)}</b></div><div class="level stop"><small>حد ضرر (SL)</small><b>${num(a.stop,5)}</b></div><div class="level target"><small>هدف (TP · ${a.rr}R)</small><b>${num(a.target,5)}</b></div></div><div class="signal-actions"><span class="muted-note">ریسک به بازده ۱:${a.rr} · زمان: ${faDate(a.metrics.candleTime)}</span><button class="tiny-btn" id="journalSignalBtn">+ ثبت در ژورنال</button></div>${shortNote?`<div class="muted-note" style="margin-top:9px;color:var(--amber)">${esc(shortNote)}</div>`:''}`;
    $('journalSignalBtn')?.addEventListener('click',addCurrentSignalToJournal);
    showSize($('sizeCard'),size);
  }
  function renderStrategies() {
    const list=$('strategyList'); const a=currentAnalysis;
    if(!a){list.innerHTML='<div class="empty-row">در انتظار تحلیل</div>';return;}
    if(!a.setups.length){list.innerHTML='<div class="empty-row">در کندل بسته‌شده اخیر، هیچ‌کدام از ستاپ‌ها فعال نشده‌اند.</div>';}
    else list.innerHTML=a.setups.map(x=>`<div class="strategy-item"><div class="strategy-left"><strong>${esc(x.name)}</strong><small>${esc(x.detail)}</small></div><span class="strategy-state ${x.direction.toLowerCase()}">${x.direction==='LONG'?'صعودی': 'نزولی'} · ${x.weight} امتیاز</span></div>`).join('');
    $('scoreSummary').textContent=`خرید ${num(a.longScore||0,1)} | فروش ${num(a.shortScore||0,1)}`;
    $('rsiValue').textContent=a.metrics.rsi!==undefined?num(a.metrics.rsi,1):'—';
    $('rsiMeter').style.width=`${Math.max(0,Math.min(100,a.metrics.rsi||0))}%`;
    $('rsiHint').textContent=a.metrics.rsi>70?'اشباع خرید':a.metrics.rsi<30?'اشباع فروش':'ناحیه میانی';
    $('atrValue').textContent=a.metrics.atr!==undefined?num(a.metrics.atr,5):'—';
  }
  function renderAnalysis(){renderSignal();renderStrategies();}

  function drawChart() {
    const canvas=$('priceChart'); if(!canvas||!activeCandles.length)return;
    const rect=canvas.getBoundingClientRect(); const width=Math.max(300,rect.width||canvas.clientWidth||350); const height=265;
    const ratio=Math.max(1,window.devicePixelRatio||1); canvas.width=Math.round(width*ratio);canvas.height=Math.round(height*ratio);
    const ctx=canvas.getContext('2d');ctx.scale(ratio,ratio);ctx.clearRect(0,0,width,height);
    const bars=activeCandles.slice(-80); if(bars.length<2)return;
    const close=bars.map(x=>x.c), e20=ema(close,20), e50=ema(close,50);
    let min=Math.min(...bars.map(x=>x.l)),max=Math.max(...bars.map(x=>x.h));
    const a=currentAnalysis;if(a&&a.direction!=='NONE'){min=Math.min(min,a.stop);max=Math.max(max,a.target);}
    const pad=(max-min)*.09||1;min-=pad;max+=pad;
    const left=8,right=68,top=13,bottom=24,plotW=width-left-right,plotH=height-top-bottom;
    const y=v=>top+(max-v)/(max-min)*plotH;
    ctx.font='9px Tahoma';ctx.textAlign='left';ctx.textBaseline='middle';
    for(let j=0;j<=4;j++){
      const yy=top+j*plotH/4;const val=max-(max-min)*j/4;
      ctx.strokeStyle='#1a3046';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(left,yy);ctx.lineTo(width-right+2,yy);ctx.stroke();
      ctx.fillStyle='#71869d';ctx.fillText(num(val,3),width-right+8,yy);
    }
    const gap=plotW/bars.length,cw=Math.max(2,Math.min(9,gap*.56));
    // Volume panel as subtle footer bars.
    const maxVol=Math.max(...bars.map(x=>x.v||0));
    if(maxVol>0){bars.forEach((c,i)=>{const x=left+i*gap+gap/2;const bh=((c.v||0)/maxVol)*24;ctx.fillStyle=c.c>=c.o?'#2ac99a30':'#ff6c7d30';ctx.fillRect(x-cw/2,top+plotH-bh,cw,bh);});}
    bars.forEach((c,i)=>{
      const x=left+i*gap+gap/2,yo=y(c.o),yc=y(c.c),yh=y(c.h),yl=y(c.l),up=c.c>=c.o;
      ctx.strokeStyle=up?'#41d6a3':'#ff6c7d';ctx.fillStyle=up?'#41d6a3':'#ff6c7d';ctx.lineWidth=1.1;
      ctx.beginPath();ctx.moveTo(x,yh);ctx.lineTo(x,yl);ctx.stroke();
      const bh=Math.max(1.5,Math.abs(yc-yo));ctx.fillRect(x-cw/2,Math.min(yo,yc),cw,bh);
    });
    function drawLine(values,color,dash=[]){ctx.beginPath();ctx.strokeStyle=color;ctx.lineWidth=1.4;ctx.setLineDash(dash);let started=false;values.forEach((v,i)=>{if(v===null)return;const x=left+i*gap+gap/2;if(!started){ctx.moveTo(x,y(v));started=true;}else ctx.lineTo(x,y(v));});ctx.stroke();ctx.setLineDash([]);}
    drawLine(e20,'#72a9ff');drawLine(e50,'#c49bff',[4,3]);
    const levels=a&&a.direction!=='NONE'?[['ورود',a.entry,'#f5bd62'],['SL',a.stop,'#ff6c7d'],['TP',a.target,'#41d6a3']]:[];
    levels.forEach(([label,val,color])=>{const yy=y(val);ctx.strokeStyle=color;ctx.setLineDash([4,3]);ctx.beginPath();ctx.moveTo(left,yy);ctx.lineTo(width-right+2,yy);ctx.stroke();ctx.setLineDash([]);ctx.fillStyle=color;ctx.fillText(label,width-right+8,yy-7);});
    const last=bars[bars.length-1];ctx.fillStyle='#dbe8f7';ctx.textAlign='right';ctx.fillText(faDate(last.t),width-right, height-10);
    $('chartRange').textContent=`${num(min,4)} — ${num(max,4)}`;
    $('candleMeta').textContent=`${bars.length} کندل · EMA20 / EMA50`;
  }

  async function loadActive(showErrors=true) {
    stopLiveFeed(); setConnection('muted','در حال دریافت داده');
    if(settings.market==='forex'&&!settings.twelveKey){
      activeCandles=[];currentAnalysis=null;renderAnalysis();drawEmptyChart();
      $('mainPrice').textContent='API Key لازم است';$('lastUpdated').textContent='تنظیمات را باز کن';
      if(showErrors)showToast('برای فارکس و طلا، API Key سرویس Twelve Data را وارد کن.');return;
    }
    try {
      const [candles,price,change] = await Promise.all([getCandles(settings.symbol,settings.timeframe,280),getPrice(),getChange()]);
      activeCandles=candles;currentPrice=price;currentChange=change;lastUpdate=Date.now();if(settings.market==='forex')lastForexCandleFetch=Date.now();
      if(!candles.length)throw new Error('کندل معتبری دریافت نشد.');
      $('mainPrice').textContent=num(price,5); $('priceChange').textContent=change===null?'تغییر روزانه در دسترس نیست':`${change>=0?'▲':'▼'} ${num(Math.abs(change),2)}% در ۲۴ ساعت`;
      $('priceChange').className='price-change '+(change===null?'':change>=0?'up':'down'); $('lastUpdated').textContent='به‌روزرسانی: '+faDate(lastUpdate);
      currentAnalysis=analyzeCandles(getClosedCandles(candles));
      $('candleMeta').textContent=`${candles.length} کندل · آخرین کندل بسته: ${faDate(getClosedCandles(candles).at(-1)?.t)}`;
      renderAnalysis();drawChart();startLiveFeed();setConnection('ok','قیمت و کندل دریافت شد');
    } catch(error) {
      console.error(error);setConnection('bad','خطا در دریافت داده');
      if(showErrors)showToast(error.message||'دریافت داده ناموفق بود. اتصال اینترنت و منبع قیمت را بررسی کن.');
      if(!activeCandles.length){$('mainPrice').textContent='داده در دسترس نیست';currentAnalysis=null;renderAnalysis();drawEmptyChart();}
    }
  }
  function drawEmptyChart(){const c=$('priceChart');if(!c)return;const ctx=c.getContext('2d');const dpr=window.devicePixelRatio||1;const w=c.getBoundingClientRect().width||340;c.width=w*dpr;c.height=265*dpr;ctx.scale(dpr,dpr);ctx.fillStyle='#8295aa';ctx.font='12px Tahoma';ctx.textAlign='center';ctx.fillText('نمودار پس از اتصال به منبع داده نمایش داده می‌شود',w/2,132);}
  async function runScanner() {
    if(scannerBusy)return;scannerBusy=true;const btn=$('scanBtn');btn.disabled=true;btn.textContent='در حال اسکن…';$('scanStatus').textContent='دریافت کندل و ارزیابی استراتژی‌ها…';$('scannerResults').innerHTML='<div class="empty-state">در حال بررسی نمادها…</div>';
    const list=activeList();
    if(settings.market==='forex'&&!settings.twelveKey){$('scannerResults').innerHTML='<div class="empty-state">برای اسکن فارکس/طلا، ابتدا API Key را در تنظیمات ذخیره کن.</div>';scannerBusy=false;btn.disabled=false;btn.innerHTML='شروع اسکن <span>⌕</span>';return;}
    try {
      const jobs=list.map(async ([symbol,label])=>{
        const candles=await getCandles(symbol,settings.timeframe,180);const closed=getClosedCandles(candles);const a=analyzeCandles(closed);
        const last=closed.at(-1);return {symbol,label,price:last?.c,analysis:a};
      });
      const results=await Promise.allSettled(jobs);
      const rows=results.map((r,i)=>r.status==='fulfilled'?r.value:{symbol:list[i][0],label:list[i][1],error:r.reason?.message||'خطا'});
      rows.sort((a,b)=>(b.analysis?.confidence||0)-(a.analysis?.confidence||0));
      $('scannerResults').innerHTML=rows.map(r=>{
        if(r.error)return `<div class="scan-row"><div class="scan-symbol"><strong>${esc(r.label)}</strong><small>خطا در دریافت داده</small></div><div class="scan-price">—</div><span class="scan-signal">ناموفق</span></div>`;
        const d=r.analysis.direction,cls=d==='LONG'?'long':d==='SHORT'?'short':'',label=d==='LONG'?'خرید':d==='SHORT'?'فروش':'بدون سیگنال';
        return `<div class="scan-row"><div class="scan-symbol"><strong>${esc(r.label)}</strong><small>امتیاز ${num(r.analysis.score,1)} · ${r.analysis.confidence}%</small></div><div class="scan-price">${num(r.price,5)}</div><span class="scan-signal ${cls}">${label}</span></div>`;
      }).join('');
      $('scanStatus').textContent=`اسکن ${rows.length} نماد · ${faDate(Date.now())}`;
    } catch(error) { $('scannerResults').innerHTML=`<div class="empty-state">${esc(error.message||'خطا در اسکن')}</div>`; }
    finally {scannerBusy=false;btn.disabled=false;btn.innerHTML='شروع اسکن <span>⌕</span>';}
  }

  function runBacktest() {
    if(activeCandles.length<100){showToast('برای بک‌تست حداقل ۱۰۰ کندل لازم است.');return;}
    const bars=activeCandles.filter(c=>c.closeTime<Date.now()-500);let trades=0,wins=0,losses=0,netR=0;
    const start=Math.max(65,bars.length-190);
    for(let i=start;i<bars.length-2;i++){
      const a=analyzeCandles(bars.slice(0,i+1));if(a.direction==='NONE')continue;
      trades++;let outcome=null;
      for(let j=i+1;j<Math.min(bars.length,i+31);j++){
        const c=bars[j];
        if(a.direction==='LONG'){
          const stopHit=c.l<=a.stop,tpHit=c.h>=a.target;
          if(stopHit){outcome=-1;break;} if(tpHit){outcome=a.rr;break;}
        } else {
          const stopHit=c.h>=a.stop,tpHit=c.l<=a.target;
          if(stopHit){outcome=-1;break;} if(tpHit){outcome=a.rr;break;}
        }
      }
      if(outcome!==null){netR+=outcome;if(outcome>0)wins++;else losses++;}
    }
    const resolved=wins+losses,rate=resolved?wins/resolved*100:0;
    showToast(`بک‌تست ${trades} سیگنال: ${resolved} معامله بسته، نرخ برد ${num(rate,1)}٪، بازده ${num(netR,1)}R`);
    $('signalCard').insertAdjacentHTML('beforeend',`<div class="muted-note" style="margin-top:12px;border-top:1px solid var(--line);padding-top:10px">بک‌تست ساده ${bars.length} کندل اخیر: ${trades} سیگنال · ${wins} برد · ${losses} باخت · نرخ برد ${num(rate,1)}٪ · جمع نتیجه ${num(netR,1)}R. کارمزد و اسلیپیج لحاظ نشده است.</div>`);
  }

  function addCurrentSignalToJournal() {
    if(!currentAnalysis||currentAnalysis.direction==='NONE')return;
    const a=currentAnalysis;const id=`${settings.symbol}-${settings.timeframe}-${a.metrics.candleTime}-${a.direction}`;
    if(journal.some(x=>x.id===id)){showToast('این سیگنال قبلاً ثبت شده است.');return;}
    const size=positionSize(a.entry,a.stop,settings);
    journal.unshift({id,symbol:settings.symbol,label:displaySymbol(settings.symbol),market:settings.market,timeframe:settings.timeframe,direction:a.direction,entry:a.entry,stop:a.stop,target:a.target,score:a.score,date:Date.now(),result:'OPEN',riskCash:size?.riskCash||null,units:size?.units||null});
    save(STORAGE.journal,journal);renderJournal();showToast('سیگنال در ژورنال ذخیره شد.');
  }
  function renderJournal() {
    const wins=journal.filter(x=>x.result==='WIN').length,losses=journal.filter(x=>x.result==='LOSS').length,closed=wins+losses;
    $('journalTotal').textContent=String(journal.length).replace(/[0-9]/g,d=>'۰۱۲۳۴۵۶۷۸۹'[+d]);$('journalWins').textContent=String(wins).replace(/[0-9]/g,d=>'۰۱۲۳۴۵۶۷۸۹'[+d]);$('journalWinRate').textContent=closed?num(wins/closed*100,1)+'٪':'—';
    if(!journal.length){$('journalList').innerHTML='<div class="empty-state">هنوز سیگنالی در ژورنال ثبت نشده است.</div>';return;}
    $('journalList').innerHTML=journal.map(x=>{
      const d=x.direction==='LONG'?'خرید':'فروش',status=x.result==='WIN'?'برد':x.result==='LOSS'?'باخت':x.result==='BE'?'سر به سر':'باز';
      return `<article class="journal-item"><div class="journal-head"><strong>${esc(x.label)} · ${d}</strong><small>${faDate(x.date)}</small></div><p>ورود ${num(x.entry,5)} · SL ${num(x.stop,5)} · TP ${num(x.target,5)} · ${esc(x.timeframe)}</p><div class="journal-controls"><span class="scan-signal ${x.result==='WIN'?'long':x.result==='LOSS'?'short':''}">${status}</span><button class="win" data-result="WIN" data-id="${esc(x.id)}">برد</button><button class="loss" data-result="LOSS" data-id="${esc(x.id)}">باخت</button><button data-result="BE" data-id="${esc(x.id)}">سر‌به‌سر</button><button class="remove" data-remove="${esc(x.id)}">حذف</button></div></article>`;
    }).join('');
    $('journalList').querySelectorAll('[data-result]').forEach(btn=>btn.addEventListener('click',()=>{const row=journal.find(x=>x.id===btn.dataset.id);if(row){row.result=btn.dataset.result;save(STORAGE.journal,journal);renderJournal();}}));
    $('journalList').querySelectorAll('[data-remove]').forEach(btn=>btn.addEventListener('click',()=>{journal=journal.filter(x=>x.id!==btn.dataset.remove);save(STORAGE.journal,journal);renderJournal();}));
  }
  function exportJournal() {
    if(!journal.length){showToast('ژورنال خالی است.');return;}
    const headers=['date','symbol','direction','timeframe','entry','stop','target','score','result','riskCash','units'];
    const lines=[headers.join(','),...journal.map(x=>headers.map(k=>`"${String(x[k]??'').replace(/"/g,'""')}"`).join(','))];
    const blob=new Blob(['\ufeff'+lines.join('\n')],{type:'text/csv;charset=utf-8;'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='tradepilot-journal.csv';a.click();URL.revokeObjectURL(url);
  }

  function calcManual() {
    const entry=Number($('manualEntry').value),stop=Number($('manualStop').value);
    if(!(entry>0&&stop>0&&entry!==stop)){showToast('قیمت ورود و حد ضرر معتبر وارد کن.');return;}
    const result=positionSize(entry,stop,settings);showSize($('manualRiskResult'),result);
    const direction=entry>stop?'LONG':'SHORT';
    $('manualRiskResult').insertAdjacentHTML('afterbegin',`<h3>نتیجه محاسبه · ${direction==='LONG'?'سناریوی خرید':'سناریوی فروش'}</h3>`);
  }
  function syncRiskInputs() {
    $('balanceInput').value=settings.balance;$('riskInput').value=settings.risk;$('leverageInput').value=settings.leverage;$('rrInput').value=String(settings.rr);
    $('settingsBalance').value=settings.balance;$('settingsRisk').value=settings.risk;
    $('riskCash').textContent=num(settings.balance*settings.risk/100,2)+' USD';
  }
  function saveRiskFromInputs() {
    const balance=Number($('balanceInput').value),risk=Number($('riskInput').value),lev=Number($('leverageInput').value),rr=Number($('rrInput').value);
    if(!(balance>0&&risk>0&&risk<=5&&lev>=1&&lev<=125)){showToast('بالانس یا درصد ریسک/اهرم معتبر نیست.');return false;}
    settings.balance=balance;settings.risk=risk;settings.leverage=lev;settings.rr=rr;persistSettings();syncRiskInputs();
    if(currentAnalysis&&currentAnalysis.direction!=='NONE')showSize($('sizeCard'),positionSize(currentAnalysis.entry,currentAnalysis.stop,settings));
    return true;
  }
  function saveAppSettings() {
    const balance=Number($('settingsBalance').value),risk=Number($('settingsRisk').value);
    if(!(balance>0&&risk>0&&risk<=5)){showToast('بالانس یا درصد ریسک نامعتبر است.');return;}
    settings.balance=balance;settings.risk=risk;settings.twelveKey=$('twelveKeyInput').value.trim();persistSettings();syncRiskInputs();showToast('تنظیمات ذخیره شد.');
    if(settings.market==='forex')loadActive();
  }
  function setTab(name) {
    document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x.dataset.tab===name));
    document.querySelectorAll('.tab-page').forEach(x=>x.classList.toggle('active',x.id===`tab-${name}`));
    if(name==='journal')renderJournal();if(name==='risk')syncRiskInputs();if(name==='overview')setTimeout(drawChart,50);
  }
  function setMarket(value) {
    settings.market=value;settings.symbol=activeList()[0][0];persistSettings();updateSymbolOptions();loadActive();
    if(value==='forex'&&!settings.twelveKey)showToast('برای فارکس و طلا API Key لازم است؛ از تنظیمات وارد کن.');
  }
  function setupAutoScan() {
    if(autoScanTimer)clearInterval(autoScanTimer);autoScanTimer=null;
    if($('autoScanToggle').checked)autoScanTimer=setInterval(()=>{if(!scannerBusy)runScanner();},300000);
  }
  function bindEvents() {
    $('refreshBtn').addEventListener('click',()=>loadActive());$('analyzeBtn').addEventListener('click',()=>loadActive());
    $('marketSelect').value=settings.market;$('marketSelect').addEventListener('change',e=>setMarket(e.target.value));
    $('symbolSelect').addEventListener('change',e=>{settings.symbol=e.target.value;persistSettings();$('assetSymbol').textContent=displaySymbol(settings.symbol);loadActive();});
    $('timeframeSelect').value=settings.timeframe;$('timeframeSelect').addEventListener('change',e=>{settings.timeframe=e.target.value;persistSettings();loadActive();});
    $('scanBtn').addEventListener('click',runScanner);$('autoScanToggle').addEventListener('change',setupAutoScan);$('backtestBtn').addEventListener('click',runBacktest);
    $('calcManualBtn').addEventListener('click',()=>{if(saveRiskFromInputs())calcManual();});
    ['balanceInput','riskInput','leverageInput','rrInput'].forEach(id=>$(id).addEventListener('change',saveRiskFromInputs));
    $('openRiskBtn').addEventListener('click',()=>setTab('risk'));
    $('saveSettingsBtn').addEventListener('click',saveAppSettings);$('twelveKeyInput').value=settings.twelveKey;
    $('exportJournalBtn').addEventListener('click',exportJournal);$('clearCacheBtn').addEventListener('click',()=>{
      if(!confirm('همه تنظیمات و ژورنال محلی این برنامه پاک شود؟'))return;
      localStorage.removeItem(STORAGE.settings);localStorage.removeItem(STORAGE.journal);journal=[];settings={...DEFAULTS};persistSettings();syncRiskInputs();$('twelveKeyInput').value='';renderJournal();updateSymbolOptions();loadActive();showToast('داده‌های محلی پاک شد.');
    });
    document.querySelectorAll('.tab').forEach(btn=>btn.addEventListener('click',()=>setTab(btn.dataset.tab)));
    window.addEventListener('resize',()=>drawChart());document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')refreshPriceOnly();});
  }

  function init() {
    updateSymbolOptions();$('marketSelect').value=settings.market;$('timeframeSelect').value=settings.timeframe;
    syncRiskInputs();bindEvents();renderJournal();loadActive(false);
    $('manualEntry').addEventListener('keydown',e=>{if(e.key==='Enter')calcManual();});
  }
  init();
})();
